AI Phone Assistant (Java, Android)

BUILD
1. Install Android Studio. File > Open > select this folder (AIPhoneAssistant).
2. Wait for Gradle sync. Plug in your Android phone (USB debugging on) and press Run.
   To get an APK file: Build > Build Bundle(s) / APK(s) > Build APK(s).

FIRST RUN ON PHONE
1. Get an API key at console.anthropic.com, paste it in the app, tap Save key.
2. Tap "Step 1" and turn on "AI Phone Assistant" under Accessibility.
   (If it is greyed out: Settings > Apps > AI Phone Assistant > menu > Allow restricted settings.)
3. Allow SMS, Contacts and Phone permissions.
4. Tap "Speak a command", e.g. "Text Rahul I will be late" or "Open WhatsApp and message Mom hello".

NOTES
- Texts and calls always ask you to confirm first.
- Needs internet (the AI runs through the API, which costs a small amount per task).
- Android only. iPhone does not allow this.
