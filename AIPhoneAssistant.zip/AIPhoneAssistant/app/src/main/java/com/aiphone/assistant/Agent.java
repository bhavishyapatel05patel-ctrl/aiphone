package com.aiphone.assistant;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Runs the loop: command -> AI -> tool call -> result -> AI ... until done. */
public class Agent {

    public interface Listener {
        void onLog(String message);
        /** Ask the user yes/no. Blocks until answered. */
        boolean confirm(String question);
    }

    private static final String API_URL = "https://api.anthropic.com/v1/messages";
    private static final String MODEL = "claude-sonnet-5-5";
    private static final int MAX_STEPS = 20;
    private static final String SYSTEM =
            "You control an Android phone for the user. Use the tools to complete the task. "
          + "After opening an app or tapping, call read_screen to see what happened before "
          + "the next step. Be brief. When the task is finished, reply with a short summary "
          + "and no tool call. If something fails twice, stop and explain.";

    private final String apiKey;
    private final Listener ui;
    private final PhoneActions actions;

    public Agent(Context ctx, String apiKey, Listener ui) {
        this.apiKey = apiKey;
        this.ui = ui;
        this.actions = new PhoneActions(ctx.getApplicationContext(), ui);
    }

    public void run(String command) {
        try {
            JSONArray messages = new JSONArray();
            messages.put(new JSONObject().put("role", "user").put("content", command));

            for (int step = 0; step < MAX_STEPS; step++) {
                JSONObject resp = callApi(messages);
                JSONArray content = resp.getJSONArray("content");
                messages.put(new JSONObject().put("role", "assistant").put("content", content));

                JSONArray results = new JSONArray();
                for (int i = 0; i < content.length(); i++) {
                    JSONObject block = content.getJSONObject(i);
                    String type = block.getString("type");
                    if (type.equals("text")) {
                        ui.onLog("AI: " + block.getString("text"));
                    } else if (type.equals("tool_use")) {
                        String name = block.getString("name");
                        JSONObject input = block.getJSONObject("input");
                        ui.onLog("> " + name + " " + input);
                        String out = actions.execute(name, input);
                        results.put(new JSONObject()
                                .put("type", "tool_result")
                                .put("tool_use_id", block.getString("id"))
                                .put("content", out));
                    }
                }
                if (results.length() == 0) return; // no tool call = finished
                messages.put(new JSONObject().put("role", "user").put("content", results));
            }
            ui.onLog("Stopped: step limit reached.");
        } catch (Exception e) {
            ui.onLog("Error: " + e.getMessage());
        }
    }

    private JSONObject callApi(JSONArray messages) throws Exception {
        JSONObject body = new JSONObject()
                .put("model", MODEL)
                .put("max_tokens", 1024)
                .put("system", SYSTEM)
                .put("tools", Tools.definitions())
                .put("messages", messages);

        HttpURLConnection c = (HttpURLConnection) new URL(API_URL).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(90000);
        c.setRequestProperty("content-type", "application/json");
        c.setRequestProperty("x-api-key", apiKey);
        c.setRequestProperty("anthropic-version", "2023-06-01");
        c.setDoOutput(true);
        try (OutputStream os = c.getOutputStream()) {
            os.write(body.toString().getBytes("UTF-8"));
        }
        int code = c.getResponseCode();
        InputStream is = code < 400 ? c.getInputStream() : c.getErrorStream();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
        String text = bos.toString("UTF-8");
        if (code >= 400) throw new RuntimeException("API " + code + ": " + text);
        return new JSONObject(text);
    }
}
