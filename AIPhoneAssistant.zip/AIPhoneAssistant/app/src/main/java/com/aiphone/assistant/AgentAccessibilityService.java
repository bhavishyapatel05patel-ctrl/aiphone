package com.aiphone.assistant;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

/** Lets the app read the screen and tap/type inside other apps. */
public class AgentAccessibilityService extends AccessibilityService {

    public static volatile AgentAccessibilityService instance;

    @Override protected void onServiceConnected() { instance = this; }

    @Override public boolean onUnbind(Intent intent) {
        instance = null;
        return super.onUnbind(intent);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override public void onInterrupt() { }

    public String readScreen() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return "Screen not readable right now.";
        StringBuilder sb = new StringBuilder();
        walk(root, sb);
        return sb.length() == 0 ? "(no visible text)" : sb.toString();
    }

    public boolean clickText(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo hit = find(root, text.toLowerCase());
        while (hit != null && !hit.isClickable()) hit = hit.getParent();
        return hit != null && hit.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    public boolean typeText(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (field == null) field = firstMatching(root, true);
        if (field == null) return false;
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    public boolean scroll(boolean down) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        AccessibilityNodeInfo list = firstMatching(root, false);
        if (list == null) return false;
        return list.performAction(down ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                                       : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
    }

    // ---- helpers ----

    private void walk(AccessibilityNodeInfo n, StringBuilder sb) {
        if (n == null || sb.length() > 6000) return;
        if (n.isVisibleToUser()) {
            String label = labelOf(n);
            if (!label.isEmpty() || n.isEditable()) {
                sb.append("- ").append(label);
                if (n.isEditable()) sb.append(" [input]");
                if (n.isClickable()) sb.append(" [clickable]");
                sb.append('\n');
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), sb);
    }

    private String labelOf(AccessibilityNodeInfo n) {
        CharSequence t = n.getText();
        CharSequence d = n.getContentDescription();
        String s = t != null ? t.toString() : "";
        if (s.isEmpty() && d != null) s = d.toString();
        return s.trim();
    }

    private AccessibilityNodeInfo find(AccessibilityNodeInfo n, String query) {
        if (n == null) return null;
        if (n.isVisibleToUser() && labelOf(n).toLowerCase().contains(query)) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = find(n.getChild(i), query);
            if (r != null) return r;
        }
        return null;
    }

    /** First editable node (editable=true) or first scrollable node (editable=false). */
    private AccessibilityNodeInfo firstMatching(AccessibilityNodeInfo n, boolean editable) {
        if (n == null) return null;
        if (editable ? n.isEditable() : n.isScrollable()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = firstMatching(n.getChild(i), editable);
            if (r != null) return r;
        }
        return null;
    }
}
