package com.aiphone.assistant;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity implements Agent.Listener {

    private static final int REQ_SPEECH = 1;
    private static final int REQ_PERMS = 2;

    private EditText keyInput;
    private EditText cmdInput;
    private TextView logView;
    private ScrollView scroll;
    private volatile boolean foreground;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        keyInput = new EditText(this);
        keyInput.setHint("Anthropic API key");
        keyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        keyInput.setText(prefs().getString("key", ""));
        root.addView(keyInput);

        root.addView(button("Save key", v -> {
            prefs().edit().putString("key", keyInput.getText().toString().trim()).apply();
            log("Key saved.");
        }));
        root.addView(button("Step 1: Enable accessibility service", v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        root.addView(button("Speak a command", v -> speak()));

        cmdInput = new EditText(this);
        cmdInput.setHint("...or type a command");
        root.addView(cmdInput);
        root.addView(button("Run", v -> run(cmdInput.getText().toString())));

        logView = new TextView(this);
        scroll = new ScrollView(this);
        scroll.addView(logView);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        requestPermissions(new String[]{
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE}, REQ_PERMS);
    }

    @Override protected void onResume() { super.onResume(); foreground = true; }

    @Override protected void onPause() { super.onPause(); foreground = false; }

    private Button button(String label, View.OnClickListener l) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setOnClickListener(l);
        return btn;
    }

    private SharedPreferences prefs() {
        return getSharedPreferences("ai_phone", MODE_PRIVATE);
    }

    private void speak() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "What should I do?");
        try {
            startActivityForResult(i, REQ_SPEECH);
        } catch (Exception e) {
            log("Speech recognition not available on this phone. Type instead.");
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_SPEECH && res == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                cmdInput.setText(r.get(0));
                run(r.get(0));
            }
        }
    }

    private void run(String command) {
        final String cmd = command.trim();
        if (cmd.isEmpty()) return;
        final String key = prefs().getString("key", "");
        if (key.isEmpty()) { log("Enter and save your API key first."); return; }
        if (AgentAccessibilityService.instance == null) {
            log("Enable the accessibility service first (Step 1).");
            return;
        }
        log("You: " + cmd);
        new Thread(() -> new Agent(this, key, this).run(cmd)).start();
    }

    // ---- Agent.Listener ----

    @Override public void onLog(String message) { log(message); }

    private void log(String s) {
        runOnUiThread(() -> {
            logView.append(s + "\n\n");
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        });
    }

    @Override public boolean confirm(String question) {
        final boolean wasForeground = foreground;
        final boolean[] answer = {false};
        final CountDownLatch latch = new CountDownLatch(1);

        if (!wasForeground && AgentAccessibilityService.instance != null) {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            AgentAccessibilityService.instance.startActivity(i);
        }
        runOnUiThread(() -> new AlertDialog.Builder(this)
                .setMessage(question)
                .setCancelable(false)
                .setPositiveButton("Yes", (d, w) -> {
                    answer[0] = true;
                    latch.countDown();
                    if (!wasForeground) moveTaskToBack(true);
                })
                .setNegativeButton("No", (d, w) -> {
                    latch.countDown();
                    if (!wasForeground) moveTaskToBack(true);
                })
                .show());
        try {
            latch.await(60, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) { }
        return answer[0];
    }
}
