package com.aiphone.assistant;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import org.json.JSONObject;

/** Executes the tools the AI asks for. */
public class PhoneActions {

    private static final String NEED_ACCESSIBILITY =
            "Accessibility service is not enabled. Ask the user to enable it.";

    private final Context ctx;
    private final Agent.Listener ui;

    public PhoneActions(Context ctx, Agent.Listener ui) {
        this.ctx = ctx;
        this.ui = ui;
    }

    public String execute(String name, JSONObject in) {
        try {
            AgentAccessibilityService s = AgentAccessibilityService.instance;
            switch (name) {
                case "send_sms":
                    return sendSms(in.getString("contact"), in.getString("message"));
                case "call_contact":
                    return call(in.getString("contact"));
                case "open_app":
                    return openApp(in.getString("app_name"));
                case "read_screen":
                    return s == null ? NEED_ACCESSIBILITY : s.readScreen();
                case "click":
                    if (s == null) return NEED_ACCESSIBILITY;
                    boolean ok = s.clickText(in.getString("text"));
                    sleep(1200);
                    return ok ? "Clicked." : "Could not find that item on screen.";
                case "type_text":
                    if (s == null) return NEED_ACCESSIBILITY;
                    return s.typeText(in.getString("text")) ? "Typed." : "No input field found.";
                case "scroll":
                    if (s == null) return NEED_ACCESSIBILITY;
                    boolean down = !in.getString("direction").equalsIgnoreCase("up");
                    boolean sc = s.scroll(down);
                    sleep(800);
                    return sc ? "Scrolled." : "Nothing to scroll.";
                case "go_back":
                    if (s == null) return NEED_ACCESSIBILITY;
                    s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
                    sleep(800);
                    return "Went back.";
                case "go_home":
                    if (s == null) return NEED_ACCESSIBILITY;
                    s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME);
                    sleep(800);
                    return "Went home.";
                default:
                    return "Unknown tool: " + name;
            }
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }

    private String sendSms(String contact, String message) {
        String number = resolveNumber(contact);
        if (number == null) return "No contact found for " + contact;
        if (!ui.confirm("Send SMS to " + contact + " (" + number + "):\n\n" + message)) {
            return "User declined to send.";
        }
        SmsManager sms = Build.VERSION.SDK_INT >= 31
                ? ctx.getSystemService(SmsManager.class) : SmsManager.getDefault();
        sms.sendMultipartTextMessage(number, null, sms.divideMessage(message), null, null);
        return "SMS sent to " + contact;
    }

    private String call(String contact) {
        String number = resolveNumber(contact);
        if (number == null) return "No contact found for " + contact;
        if (!ui.confirm("Call " + contact + " (" + number + ")?")) return "User declined.";
        launch(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number)));
        return "Calling " + contact;
    }

    private String openApp(String appName) {
        PackageManager pm = ctx.getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        String want = appName.toLowerCase();
        for (ResolveInfo ri : pm.queryIntentActivities(main, 0)) {
            String label = ri.loadLabel(pm).toString();
            if (label.toLowerCase().contains(want)) {
                Intent i = pm.getLaunchIntentForPackage(ri.activityInfo.packageName);
                if (i != null) {
                    launch(i);
                    sleep(2000);
                    return "Opened " + label;
                }
            }
        }
        return "App not found: " + appName;
    }

    /** Returns a phone number for a name (searches contacts) or the number itself. */
    private String resolveNumber(String contact) {
        if (contact.matches("[+0-9 \\-()]{6,}")) return contact.replaceAll("[ \\-()]", "");
        Cursor c = ctx.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                new String[]{"%" + contact + "%"}, null);
        try {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } finally {
            if (c != null) c.close();
        }
        return null;
    }

    /** Start an activity using the accessibility service (allowed from the background). */
    private void launch(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        Context c = AgentAccessibilityService.instance != null
                ? AgentAccessibilityService.instance : ctx;
        c.startActivity(i);
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { }
    }
}
