package com.aiphone.assistant;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Arrays;

/** Tool definitions the AI model can call. */
public class Tools {

    static JSONArray definitions() throws Exception {
        JSONArray a = new JSONArray();
        a.put(tool("send_sms", "Send a text message to a contact name or phone number.",
                props("contact", "Contact name or phone number", "message", "Text to send"),
                "contact", "message"));
        a.put(tool("call_contact", "Call a contact name or phone number.",
                props("contact", "Contact name or phone number"), "contact"));
        a.put(tool("open_app", "Open an installed app by name, for example WhatsApp.",
                props("app_name", "Name of the app"), "app_name"));
        a.put(tool("read_screen", "Get the visible text and buttons on the current screen.",
                new JSONObject()));
        a.put(tool("click", "Tap an item whose text or description contains the given text.",
                props("text", "Text or description of the item"), "text"));
        a.put(tool("type_text", "Type text into the focused input field (or the first one).",
                props("text", "Text to type"), "text"));
        a.put(tool("scroll", "Scroll the current screen.",
                props("direction", "down or up"), "direction"));
        a.put(tool("go_back", "Press the Back button.", new JSONObject()));
        a.put(tool("go_home", "Go to the home screen.", new JSONObject()));
        return a;
    }

    static JSONObject props(String... kv) throws Exception {
        JSONObject p = new JSONObject();
        for (int i = 0; i < kv.length; i += 2) {
            p.put(kv[i], new JSONObject().put("type", "string").put("description", kv[i + 1]));
        }
        return p;
    }

    static JSONObject tool(String name, String desc, JSONObject props, String... required)
            throws Exception {
        JSONObject schema = new JSONObject()
                .put("type", "object")
                .put("properties", props)
                .put("required", new JSONArray(Arrays.asList(required)));
        return new JSONObject()
                .put("name", name)
                .put("description", desc)
                .put("input_schema", schema);
    }
}
